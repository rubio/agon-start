# AGON_DEMO_06_SPRITES3
Agon Light 2 Demo sprite with animation and movement of a 16x16 sprite Part3.<br>
**** GLITCHY, see AGON_DEMO_07_SPRITES4 for better version*****.

Please put 4x 16x16 pixel .rgb file (created in sped, the agon lights sprite editor) somewhere on your sdcard and make a note of the full file name and path. (use the included one for the purpose of this demo) I have my files named "bombr1.rgb", "bombr2.rgb", "bombl2.rgb" & "bombl2.rgb"  in the following path "/B/Images/ . so line 180 TO 192, I have the following for F$ "/B/Images/bombr1.rgb" & "/B/Images/bombr2.rgb" etc.
