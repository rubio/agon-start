# AGON_DEMO_04_SPRITES1
Agon Light 2 Demo using and moving a simple 16x16 sprite across the screen.<br>

Please put a 16x16 pixel .rgb file (created in sped, the agon lights spright editor) somewhere on your sdcard and make a note of the full file name and path. (use the included one for the purpose of this demo)<br>
I have my file named "80A.rgb" in the following path "/B/Images/ . <br>
so line 170 & 1300 have the following for F$  "/B/Images/80A.rgb"

LUIS doing a great job on his YouTube channel.
Keep up the great work buddy.
