# AGON_DEMO_03_UDC3
The same as AGON_DEMO_02_UDC2 but now with KungFu Man (designed by net-angel).<br>
Included is a file with the Agon Lights current VDU Commands.
