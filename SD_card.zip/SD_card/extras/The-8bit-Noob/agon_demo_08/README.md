# AGON_DEMO_08_DRAWTEXT1
Agon Light 2 Demo draw text and scale Part1.<br>

A simple way to draw letters/words and scale them.
I used a 16x16 pixel grid to create my letters then did all draw and move commands based off the bottom left corner being 0,0.
Then added the scaling.
