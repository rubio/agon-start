# AGON_DEMO_07_SPRITES4
Agon Light 2 Demo sprite with animation and movement,  16x16 sprites Part4. <br>

Please put 6x 16x16 pixel .rgb files (created in sped, The agon light sprite editor) somewhere on your sdcard and make a note of the full file name and path. (use the included one for the purpose of this demo) I have my files named "bombr1.rgb", "bombr2.rgb", "bombl1.rgb", "bombl2.rgb", "bombud1.rgb", "bombud2.rgb"  in the following path "/B/Images/ . so line 220 TO 270, I have the following for F$ "/B/Images/bombr1.rgb" & "/B/Images/bombr2.rgb" etc.
