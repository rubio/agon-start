# AGON_DEMO_05_SPRITES2
Agon Light 2 Demo sprite with animation and movement of  a simple 16x16 sprite Part2.

Please put 2x 16x16 pixel .rgb file (created in sped, the agon lights sprite editor) somewhere on your sdcard and make a note of the full file name and path. (use the included one for the purpose of this demo)
I have my files named "bombw1.rgb" & "bombw2.rgb" in the following path "/B/Images/ .
so line 180 & 190 have the following for F$ "/B/Images/bombw1.rgb" & "/B/Images/bombw2.rgb".
