Theese files are Agon Light default 64 colors palette .pal files for Aseprite and Pro Motion NG.
