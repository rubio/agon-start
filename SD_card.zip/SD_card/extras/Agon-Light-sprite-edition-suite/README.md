# Agon Light sprite edition suite

This is a suite of tools to create sprites for the Agon Light computers.


![screenshot1](spredit/screenshot1.jpg)


DjPoke
