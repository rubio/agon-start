# Haunted_House
Agon Light2 Text Adventure Game, Written in BBC BASIC.<BR>
The game comes from this great old book from the 80's <br> https://colorcomputerarchive.com/repo/Documents/Books/Write%20Your%20Own%20Adventure%20Programs%20(1983)(Usborne).pdf<br>
It is set in an old creepy haunted house.<BR>
Your aim is to navigate around the house and its scary grounds
and collect all the hidden objects, you will need to work out the correct path
and the order of things that need collecting.<BR>

If you manage to collect all the items and visit all the area's then and manage to get back to the Iron Gate (your start location) then your final score will be doubled.<BR>

# Commands
All commands need to be in capital letters.<BR>
Type "HELP" at any time to get a list of allowed commands.<BR>
Allowed Commands:<BR>
GO,N,S,W,E,U,D,GET,TAKE,OPEN,EXAMINE,READ,SAY,DIG,SWING,CLIMB,LIGHT,UNLIGHT,SPRAY,USE,UNLOCK,LEAVE.<BR>
To navigate through your quest you can use the one letter direction commands (N,S,E,W) followed by the Enter key.<BR>

If you find the bugs that are in no doubt included with this code then please go easy, I'm a Noob ;-)<BR>
