# AgonLight-Game-Library
Games for the BBC Micro & Electron converted to run the on AgonLight or Agon Console8

GRANDPRIX.BAS = Fully Working

COSMICINVADERS.BAS = Playable but issues with the graphics need to be tracked down.
Requires 1.04/2.0.0 Modes

MINEFIELD.BAS = Fully Working

SUPERSTARTREK.BAS = Requires 1.04/2.0.0+ Modes

3DMAZE.BAS = Requires 1.04/2.0.0+ Modes

ENCHANTED.BAS = Enchanted Castle Adventure

FOXNHOUNDS.BAS = FOX AND HOUNDS

FOURCOLORS.BAS = FOUR COLORS (MASTERMIND) Requires 1.04/2.0.0+ Modes

MUNCHMAN.BAS/MUNCH2.BAS = MUNCHMAN Requires 1.04/2.0.0+ Modes
